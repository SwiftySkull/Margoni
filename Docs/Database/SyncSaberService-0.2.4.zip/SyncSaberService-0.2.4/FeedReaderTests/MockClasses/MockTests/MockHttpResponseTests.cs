using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using System.Linq;
using System.IO;
using FeedReader;
using Newtonsoft.Json.Linq;

namespace FeedReaderTests.MockClasses.MockTests
{
    [TestClass]
    public class MockHttpResponseTests
    {
        
    }
}
